# TODO importy zakladnich knihoven (modulu)

# TODO importy vlastnich modulu


# TODO promenne
# zivoty = 
# hra_bezi = 

# slovo = 
# tajenka = 

# TODO hlavni smycka hry

    # TODO zobraz tajenku

    # TODO input
    
    # TODO pokud uzivatel uhadl cele slovo

    # TODO pokud uzivatel uhadne pismeno
   
    # TODO pokud uzivatel uhadl spatne pismeno

# TODO vypis else po tom, co je while cyklus prerusen

