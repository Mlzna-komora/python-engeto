import Multi_modul

'''
spousta kodu
spousta kodu
spousta kodu
'''

print(Multi_modul.slovnicek)

'''
spousta kodu
spousta kodu
spousta kodu
'''
