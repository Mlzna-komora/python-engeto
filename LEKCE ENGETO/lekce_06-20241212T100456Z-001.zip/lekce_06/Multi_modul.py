muj_string = "Python je cool!"

moje_cislo = 39

seznam = [100, 300, 10000]

slovnicek = {
    'jmeno': 'Radim',
    'prijmeni': 'Jedlicka'
}

# if __name__ == '__main__':
print(muj_string)
print(moje_cislo)
print(seznam)
print(slovnicek)

