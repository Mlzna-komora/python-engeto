print("Python je cool!")
print()
print()
