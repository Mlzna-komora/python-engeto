pozdrav = "Ahoj pozemšťane"

listek = [100, 200, 'Radim']
