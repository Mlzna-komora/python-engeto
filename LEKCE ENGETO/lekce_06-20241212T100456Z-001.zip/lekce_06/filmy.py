# slovniky s informacemi o filmech

akcni = {
    'Die Hard': {
        'rezie': 'John McTiernan',
        'hraje': 'Bruce Willis',
        'hudba': 'Michael Kamen'}
        ,
    'Rambo': {
        'rezie': 'Ted Kotcheff',
        'hraje': 'Sylvester Stallone',
        'hudba': 'Jerry Goldsmith'}
        ,
    'Terminator': {
        'rezie': 'James Cameron',
        'hraje': 'Arnold Schwarzenegger',
        'hudba': 'Brad Fiedel'}
        ,
}

komedie = {
    'Kindergarten Cop': {
        'rezie': 'Ivan Reitman',
        'hraje': 'Arnold Schwarzenegger',
        'hudba': 'Randy Edelman'}
        ,
    'Evolution': {
        'rezie': 'Ivan Reitman',
        'hraje': 'David Duchovny',
        'hudba': 'John Powell'}
        ,
    'Obecna skola': {
        'rezie': 'Jan Svěrák',
        'hraje': 'Jan Tříska',
        'hudba': 'Jiří F. Svoboda'}
        ,
}

scifi = {
    'Star Wars': {
        'rezie': 'George Lucas',
        'hraje': 'Harrison Ford',
        'hudba': 'John Williams'}
        ,
    'Lord Of The Rings': {
        'rezie': 'Peter Jackson',
        'hraje': 'Elijah Wood',
        'hudba': 'Howard Shore'}
        ,
    'X-men': {
        'rezie': 'Bryan Singer',
        'hraje': 'Hugh Jackman',
        'hudba': 'Michael Kamen'}
        ,
}




